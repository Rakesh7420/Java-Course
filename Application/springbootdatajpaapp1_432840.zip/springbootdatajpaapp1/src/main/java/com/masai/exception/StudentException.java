package com.masai.exception;

public class StudentException extends RuntimeException {
	
	public StudentException() {
		// TODO Auto-generated constructor stub
	}
	
	public StudentException(String message) {
		super(message);
	}
	

}
