package com.masai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootdatajpaapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootdatajpaapp1Application.class, args);
	}

}
